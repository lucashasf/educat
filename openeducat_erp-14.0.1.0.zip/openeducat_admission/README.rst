This is gives the feature of admission process.
